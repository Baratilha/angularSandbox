import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from 'src/app/models/user/user';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})

export class UsersComponent implements OnInit {
  user: User = {
    firstName: '',
    lastName: '',
    age: null,
    email: ''
    /* address: {
      street: '',
      city: '',
      state: ''
    } */
  };
  users: User[];
  showExtended = false;
  loaded = false;
  enableAdd: boolean;
  /* currentClasses = {};
  currentStyles = {}; */
  showUserForm: boolean;
  @ViewChild('userForm') form: any;
  data: any;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getData().subscribe(data => {
      console.log(data);
    });

    this.userService.getUsers().subscribe(users => {
      this.users = users;
      this.loaded = true;
    });

    /* this.addUser({
      firstName: 'David',
      lastName: 'Jackson'
    }); */

    /* this.setCurrentClasses();
    this.setCurrentStyles(); */
  }

  addUser() {
    this.user.isActive = true;
    this.user.registered = new Date();
    this.users.unshift(this.user);
    this.user = {
      firstName: '',
      lastName: '',
      age: null,
      email: ''
      /* address: {
        street: '',
        city: '',
        state: ''
      } */
    };
  }

  onSubmit({value, valid}: {value: User, valid: boolean}) {
    // e.preventDefault();
    if (!valid) {
      alert('Form is not valid');
    } else {
      value.isActive = true;
      value.registered = new Date();
      value.hide = true;
      // this.users.unshift(value);
      this.userService.addUser(value);
      this.form.reset();
    }
  }

  /* toggleHide(user: User) {
    user.hide = !user.hide;
  } */

  /* setCurrentClasses() {
    this.currentClasses = {
      'btn-success': this.enableAdd,
      'big-text': this.showExtended
    };
  } */

  /* setCurrentStyles() {
    this.currentStyles = {
      'padding-top': this.showExtended ? '0' : '50px',
      'font-size': this.showExtended ? '' : '40px'
    };
  } */

}
